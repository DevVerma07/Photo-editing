<!DOCTYPE html>
<html>
<head>
	<title>home</title>
</head>
<body>
















<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

    <title></title>
  </head>
  <body>
    <h1></h1>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    -->


  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
     

<div class="container">
  <h3></h3>
  <p>
  <p></p>
</div>




	<p style="text-align: center; text-decoration-style: italic; size: 100px;"> k Here are more than 20 of my favorite photography quotes from famous people like Ansel Adams, Andy Warhol, and even Abraham Lincoln.
</p>
<label style="">Abraham Lincoln
Abe Lincoln said There are no bad pictures; that's just how your face looks sometimes. See what other famous people said about photography in this article of the best quotes.
“There are no bad pictures; that’s just how your face looks sometimes.”
Abraham Lincoln

Ansel Adams
Nice Ansel Adams Quote. See more quotes by Ansel Adams by clicking on this Pin.
“There are always two people in every picture: the photographer and the viewer.”
Ansel Adams</label>


<div class="divide80"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-6 margin20">
                    <h3 style="color: rgb(100,20,0);" class="heading" >Abraham lincoln</h3>
                    <p style="color: rgb(10,100,0);">
                        Abe Lincoln said There are no bad pictures; that's just how your face looks sometimes. See what other famous people said about photography in this article of the best quotes.
“There are no bad pictures; that’s just how your face looks sometimes.”
Abraham Lincoln

Ansel Adams
Nice Ansel Adams Quote. See more quotes by Ansel Adams by clicking on this Pin.
“There are always two people in every picture: the photographer and the viewer.”
Ansel Adams
                    </p>
                    
                </div>
                <div class="divide80"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-6 margin20">
                    <h3 class="heading">Ansel Adams</h3>
                    <p>

A good photograph is knowing where to stand. Which of the sayings on this page is your favorite?
“A good photograph is knowing where to stand.”
Ansel Adams
                        
                    </p>
                    
                </div>
<img src="img/camera.jpg">

    </div>
                <div class="divide80"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-6 margin20">
                    <h3 class="heading">Ansel Adams</h3>
                    <p>
<h3 class="heading">Burk Uzzle</h3>
Photography is a love affair with life. Check out more famous photographyquotes here.
“Photography is a love affair with life.”
Burk Uzzle
</p>
                            <ul class="list-inline">
                            <li>
                                <a href="#" class="social-icon-sm si-border si-facebook">
                                    <i class="fa fa-facebook"></i>
                                    <i class="fa fa-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="social-icon-sm si-border si-twitter">
                                    <i class="fa fa-twitter"></i>
                                    <i class="fa fa-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="social-icon-sm si-border si-linkedin">
                                    <i class="fa fa-linkedin"></i>
                                    <i class="fa fa-linkedin"></i>
                                </a>
                            </li>
                        </ul>
</div>

<h4 class="heading" >Inspirational Photography Quotes Video
Photography Quotes</h4>

</div>

<img src="img/a1.jpg" class="img-responsive" style="width: 1000px": height="700px"  alt="">

                <div class="divide80"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-6 margin20">
                    <h3 class="heading">Robert Capa</h3>
                    <p>
Robert Capa
One of my favorite quotes. 20 more in this list (click above).
“If your pictures are not good enough you are not close enough.”
Robert Capa

                        
                    </p>
                    
                </div>
<img src="img/a2.jpg" class="img-responsive" style="width: 1000px": height="700px"  alt="">


                <div class="divide80"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-6 margin20">
                    <h3 class="heading">Ansel Adams</h3>

                    <p>

There are no rules for good photographs, there are only good photographs. See 20 more photography quotes on this page.
“There are no rules for good photographs, there are only good photographs.”
Ansel Adams


                        
                    </p>
                    
                    
                </div>

                <img src="img/a3.jpg" class="img-responsive" style="width: 1000px": height="700px"   alt="">

                <div class="divide80"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-6 margin20">
                    <h3 class="heading">Tim Walker</h3>
                    <p>
Tim Walker
Only photograph what you love - Tim Walker. View the full list of famous photography quotes here.
“Only photograph what you love.”
Tim Walker

                        
                    </p>
                <p><a href="index.php" class="previous">&laquo; Previous</a>
<a href="images.php" class="next">Next &raquo;</a>

<a href="#" class="previous round">&#8249;</a>
<a href="#" class="next round">&#8250;</a>
</p>
                    
                </div>

           





                        
                   



</body>
</html>