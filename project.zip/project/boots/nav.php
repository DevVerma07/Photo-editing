<nav class="navbar navbar-inverse">
   	<div class="container-fluid">
   		<div class="navbar-header">
   			<a class="navbar-brand" href="">RitManagement</a>
   		</div>
   		<ul class="nav navbar-nav">
   			<li><a href="">Home</a></li>
   			<li><a href="">About</a></li>
   			<li><a href="">Gallery</a></li>
   			<li><a href="student_registration.php">Student Register</a></li>
   			<li><a href="student_record.php">Student Record</a></li>
   		</ul>
   	</div>
   	
   </nav>