<!DOCTYPE html>
<html>
<head>
	
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="boot/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="boot/css/bootstrap.min.css">
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>







  
   <div class="container">
   	<div class="row">
   		<div class="col-md-12">
        <h1 class="text-center text-primary text-light">Self login</h1>
   			<form class="form-vertical" action="form_submit1.php" method="post">
   				
          <div class="form-group">
            <label for="Email" style="color: green">Email*:</label>
            <input type="email" name="n1" class="form-control"  required="">
          </div>
         
          <div class="form-group">
            <label for="Password" style="color: green">Password*:</label>
            <input type="password" name="n2" class="form-control" required="">
          </div>
         
   				<div class="form-group">
   					<input type="submit" name="submit" value="submit" class="btn btn-primary btn-lg">
   				</div>
   			</form>
   			
   		</div>
   	</div>
   </div>
</body>
</html>

	